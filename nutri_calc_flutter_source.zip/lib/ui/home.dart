import 'dart:convert';
import 'package:flutter/material.dart';
import '../models.dart';
import '../calc.dart';
import 'package:flutter/services.dart' show rootBundle;

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Recipe> recipes = [];
  List<Fertilizer> ferts = [];
  Recipe? selected;
  String? selectedCrop;
  String? selectedStage;

  double finalVolume = 1000;
  double multiple = 100;
  double stockA = 10;
  double stockB = 10;

  CalcResult? result;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final rj = await rootBundle.loadString('lib/data/recipes.json');
    final fj = await rootBundle.loadString('lib/data/fertilizers.json');
    final rList = (json.decode(rj) as List).map((e) => Recipe.fromMap(e)).toList();
    final fList = (json.decode(fj) as List).map((e) => Fertilizer.fromMap(e)).toList();
    setState(() {
      recipes = rList;
      ferts = fList;
      final crops = rList.map((e) => e.crop).toSet().toList();
      if (crops.isNotEmpty) selectedCrop = crops.first;
      final stages = rList.where((e) => e.crop == selectedCrop).map((e) => e.stage).toSet().toList();
      if (stages.isNotEmpty) selectedStage = stages.first;
      selected = rList.firstWhere((e) => e.crop == selectedCrop && e.stage == selectedStage);
      _recalc();
    });
  }

  void _recalc() {
    if (selected == null) return;
    result = Calculator.compute(
      r: selected!,
      ferts: ferts,
      finalVolumeL: finalVolume,
      stockMultiple: multiple,
      stockAVolL: stockA,
      stockBVolL: stockB,
    );
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final crops = recipes.map((e) => e.crop).toSet().toList()..sort();
    final stages = recipes.where((e) => e.crop == selectedCrop).map((e) => e.stage).toSet().toList()..sort();
    return Scaffold(
      appBar: AppBar(title: const Text("Hydroponic A/B Calculator")),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: ListView(
          children: [
            const Text("Select Recipe", style: TextStyle(fontWeight: FontWeight.bold)),
            Row(
              children: [
                Expanded(
                  child: DropdownButton<String>(
                    isExpanded: true,
                    value: selectedCrop,
                    items: crops.map((c)=>DropdownMenuItem(value: c, child: Text(c))).toList(),
                    onChanged: (v){
                      setState(() {
                        selectedCrop = v;
                        selectedStage = null;
                        selected = null;
                      });
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: DropdownButton<String>(
                    isExpanded: true,
                    value: selectedStage,
                    items: stages.map((s)=>DropdownMenuItem(value: s, child: Text(s))).toList(),
                    onChanged: (v){
                      setState(() {
                        selectedStage = v;
                        selected = recipes.firstWhere((e) => e.crop == selectedCrop && e.stage == selectedStage);
                        _recalc();
                      });
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Text("Inputs", style: TextStyle(fontWeight: FontWeight.bold)),
            Row(children: [
              Expanded(child: _numField("Final volume (L)", finalVolume, (x){ finalVolume = x; _recalc(); })),
              const SizedBox(width: 8),
              Expanded(child: _numField("Stock multiple (×)", multiple, (x){ multiple = x; _recalc(); })),
            ]),
            Row(children: [
              Expanded(child: _numField("Stock A volume (L)", stockA, (x){ stockA = x; _recalc(); })),
              const SizedBox(width: 8),
              Expanded(child: _numField("Stock B volume (L)", stockB, (x){ stockB = x; _recalc(); })),
            ]),
            const SizedBox(height: 12),
            if (selected != null) _targetsCard(selected!),
            const SizedBox(height: 12),
            if (result != null) _resultsCard(result!, ferts),
          ],
        ),
      ),
    );
  }

  Widget _numField(String label, double value, void Function(double) onChanged) {
    final ctrl = TextEditingController(text: value.toStringAsFixed(2));
    return TextField(
      controller: ctrl,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      onSubmitted: (v){
        final parsed = double.tryParse(v);
        if (parsed != null) onChanged(parsed);
      },
    );
  }

  Widget _targetsCard(Recipe r) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Targets (ppm) ${r.crop} - ${r.stage}", style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 12, runSpacing: 8,
              children: [
                _chip("N", r.n), _chip("P", r.p), _chip("K", r.k),
                _chip("Ca", r.ca), _chip("Mg", r.mg), _chip("S", r.s),
                _chip("Fe", r.fe), _chip("Mn", r.mn), _chip("Zn", r.zn),
                _chip("Cu", r.cu), _chip("B", r.b), _chip("Mo", r.mo),
                Chip(label: Text("pH ${r.ph}")), Chip(label: Text("EC ${r.ec} dS/m")),
              ],
            )
          ],
        ),
      ),
    );
  }

  Widget _chip(String k, double v) => Chip(label: Text("$k ${v.toStringAsFixed(2)}"));

  Widget _resultsCard(CalcResult res, List<Fertilizer> ferts) {
    final tiles = <Widget>[];
    tiles.add(const Text("Direct mix (g)", style: TextStyle(fontWeight: FontWeight.bold)));
    tiles.addAll(ferts.map((f) => _kv("${f.name}", res.directMix[f.name]!.toStringAsFixed(2))).toList());
    tiles.add(const SizedBox(height: 8));
    tiles.add(const Text("Stock A (g)", style: TextStyle(fontWeight: FontWeight.bold)));
    tiles.addAll(ferts.where((f)=>f.tank.toUpperCase()=="A").map((f) => _kv("${f.name}", res.stockA[f.name]!.toStringAsFixed(2))).toList());
    tiles.add(const SizedBox(height: 8));
    tiles.add(const Text("Stock B (g)", style: TextStyle(fontWeight: FontWeight.bold)));
    tiles.addAll(ferts.where((f)=>f.tank.toUpperCase()=="B").map((f) => _kv("${f.name}", res.stockB[f.name]!.toStringAsFixed(2))).toList());
    tiles.add(const SizedBox(height: 8));
    tiles.add(_kv("N supplied vs target (g)", "${res.nSupplied.toStringAsFixed(2)} / ${res.nTarget.toStringAsFixed(2)}"));

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: tiles),
      ),
    );
  }

  Widget _kv(String k, String v) {
    return Row(
      children: [
        Expanded(child: Text(k)),
        Text(v, style: const TextStyle(fontFeatures: [FontFeature.tabularFigures()])),
      ],
    );
  }
}