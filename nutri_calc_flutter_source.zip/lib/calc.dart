import 'models.dart';

class CalcResult {
  final Map<String, double> directMix; // fertilizer -> grams
  final Map<String, double> stockA;    // fertilizer -> grams
  final Map<String, double> stockB;    // fertilizer -> grams
  final double nSupplied;
  final double nTarget;

  CalcResult({
    required this.directMix,
    required this.stockA,
    required this.stockB,
    required this.nSupplied,
    required this.nTarget,
  });
}

class Calculator {
  static CalcResult compute({
    required Recipe r,
    required List<Fertilizer> ferts,
    required double finalVolumeL,
    required double stockMultiple,
    required double stockAVolL,
    required double stockBVolL,
  }) {
    // grams of each element needed for the final volume
    double gN  = r.n  * finalVolumeL / 1000.0;
    double gP  = r.p  * finalVolumeL / 1000.0;
    double gK  = r.k  * finalVolumeL / 1000.0;
    double gCa = r.ca * finalVolumeL / 1000.0;
    double gMg = r.mg * finalVolumeL / 1000.0;
    double gS  = r.s  * finalVolumeL / 1000.0;
    double gFe = r.fe * finalVolumeL / 1000.0;
    double gMn = r.mn * finalVolumeL / 1000.0;
    double gZn = r.zn * finalVolumeL / 1000.0;
    double gCu = r.cu * finalVolumeL / 1000.0;
    double gB  = r.b  * finalVolumeL / 1000.0;
    double gMo = r.mo * finalVolumeL / 1000.0;

    // Find key fertilizers by simple name contains
    Fertilizer? fCa = ferts.firstWhere((f) => f.name.toLowerCase().contains("calcium nitrate"), orElse: () => ferts.first);
    Fertilizer? fKNO3 = ferts.firstWhere((f) => f.name.toLowerCase().contains("potassium nitrate"), orElse: () => ferts.first);
    Fertilizer? fKH2PO4 = ferts.firstWhere((f) => f.name.toLowerCase().contains("monopotassium phosphate"), orElse: () => ferts.first);
    Fertilizer? fMgSO4 = ferts.firstWhere((f) => f.name.toLowerCase().contains("magnesium sulfate"), orElse: () => ferts.first);
    Fertilizer? fK2SO4 = ferts.firstWhere((f) => f.name.toLowerCase().contains("potassium sulfate"), orElse: () => ferts.first);
    Fertilizer? fFe = ferts.firstWhere((f) => f.name.toLowerCase().contains("chelate"), orElse: () => ferts.first);
    Fertilizer? fTE = ferts.firstWhere((f) => f.name.toLowerCase().contains("premix"), orElse: () => ferts.first);

    Map<String,double> grams = { for (var f in ferts) f.name : 0.0 };

    // 1) P from KH2PO4: grams fertilizer = grams P / P%
    if (fKH2PO4.p > 0) {
      grams[fKH2PO4.name] = gP / fKH2PO4.p;
    }
    // 2) Mg from MgSO4
    if (fMgSO4.mg > 0) {
      grams[fMgSO4.name] = gMg / fMgSO4.mg;
    }
    // 3) Ca from Ca nitrate
    if (fCa.ca > 0) {
      grams[fCa.name] = gCa / fCa.ca;
    }
    // 4) K remaining after KH2PO4
    double kFromKH2PO4 = (grams[fKH2PO4.name] ?? 0.0) * fKH2PO4.k;
    double kRemain = (gK - kFromKH2PO4).clamp(0, double.infinity);
    if (fKNO3.k > 0) {
      grams[fKNO3.name] = kRemain / fKNO3.k;
    }

    // 5) Fe from Fe-chelate
    if (fFe.fe > 0) {
      grams[fFe.name] = gFe / fFe.fe;
    }
    // 6) TE premix sized to largest requirement among Mn, Zn, Cu, B, Mo
    double reqMn = fTE.mn>0 ? gMn/fTE.mn : 0;
    double reqZn = fTE.zn>0 ? gZn/fTE.zn : 0;
    double reqCu = fTE.cu>0 ? gCu/fTE.cu : 0;
    double reqB  = fTE.b >0 ? gB /fTE.b  : 0;
    double reqMo = fTE.mo>0 ? gMo/fTE.mo : 0;
    grams[fTE.name] = [reqMn,reqZn,reqCu,reqB,reqMo].reduce((a,b)=> a>b?a:b);

    // N supplied (from CaNO3 and KNO3)
    double nSupplied = (grams[fCa.name]! * fCa.n) + (grams[fKNO3.name]! * fKNO3.n);

    // Stock computations
    // grams_per_L_stock = DirectMix_grams * (stockMultiple / finalVolumeL)
    // Then per tank by tank assignment
    Map<String,double> stockA = {};
    Map<String,double> stockB = {};
    for (var f in ferts) {
      final dm = grams[f.name] ?? 0.0;
      final gramsPerLStock = dm * (stockMultiple / finalVolumeL);
      if (f.tank.toUpperCase() == "A") {
        stockA[f.name] = gramsPerLStock * stockAVolL;
        stockB[f.name] = 0;
      } else {
        stockB[f.name] = gramsPerLStock * stockBVolL;
        stockA[f.name] = 0;
      }
    }

    return CalcResult(
      directMix: grams,
      stockA: stockA,
      stockB: stockB,
      nSupplied: nSupplied,
      nTarget: gN,
    );
  }
}