class Recipe {
  final String crop;
  final String stage;
  final double n;
  final double p;
  final double k;
  final double ca;
  final double mg;
  final double s;
  final double fe;
  final double mn;
  final double zn;
  final double cu;
  final double b;
  final double mo;
  final String ph;
  final String ec;

  const Recipe({
    required this.crop,
    required this.stage,
    required this.n,
    required this.p,
    required this.k,
    required this.ca,
    required this.mg,
    required this.s,
    required this.fe,
    required this.mn,
    required this.zn,
    required this.cu,
    required this.b,
    required this.mo,
    required this.ph,
    required this.ec,
  });

  factory Recipe.fromMap(Map<String, dynamic> m) => Recipe(
    crop: m["Crop"],
    stage: m["Stage"],
    n: (m["N"] as num).toDouble(),
    p: (m["P"] as num).toDouble(),
    k: (m["K"] as num).toDouble(),
    ca: (m["Ca"] as num).toDouble(),
    mg: (m["Mg"] as num).toDouble(),
    s: (m["S"] as num).toDouble(),
    fe: (m["Fe"] as num).toDouble(),
    mn: (m["Mn"] as num).toDouble(),
    zn: (m["Zn"] as num).toDouble(),
    cu: (m["Cu"] as num).toDouble(),
    b: (m["B"] as num).toDouble(),
    mo: (m["Mo"] as num).toDouble(),
    ph: m["pH"],
    ec: m["EC"],
  );
}

class Fertilizer {
  final String name;
  final double n;
  final double p;
  final double k;
  final double ca;
  final double mg;
  final double s;
  final double fe;
  final double mn;
  final double zn;
  final double cu;
  final double b;
  final double mo;
  final String tank; // "A" or "B"
  final String note;

  const Fertilizer({
    required this.name,
    required this.n,
    required this.p,
    required this.k,
    required this.ca,
    required this.mg,
    required this.s,
    required this.fe,
    required this.mn,
    required this.zn,
    required this.cu,
    required this.b,
    required this.mo,
    required this.tank,
    required this.note,
  });

  factory Fertilizer.fromMap(Map<String, dynamic> m) => Fertilizer(
    name: m["Fertilizer"],
    n: (m["N"] as num).toDouble(),
    p: (m["P"] as num).toDouble(),
    k: (m["K"] as num).toDouble(),
    ca: (m["Ca"] as num).toDouble(),
    mg: (m["Mg"] as num).toDouble(),
    s: (m["S"] as num).toDouble(),
    fe: (m["Fe"] as num).toDouble(),
    mn: (m["Mn"] as num).toDouble(),
    zn: (m["Zn"] as num).toDouble(),
    cu: (m["Cu"] as num).toDouble(),
    b: (m["B"] as num).toDouble(),
    mo: (m["Mo"] as num).toDouble(),
    tank: m["Tank"],
    note: m["Note"] ?? "",
  );
}